#!/bin/bash

grep "XX:XX:XX AM/|PM" *_Dealer_schedule | awk '{print ($1,$2,$5,$6)}' *_Dealer_schedule
chmod +x roulette_dealer_finder_by_time.sh

