#!/bin/bash

sed -n 1p ~/Lucky_Duck_Investigations/Roulette_Loss_Investigation/Dealer_Analysis/0310_Dealer_schedule | cat > Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0310_Dealer_schedule | grep '05:00:00 AM' 0310_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0310_Dealer_schedule | grep '08:00:00 AM' 0310_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0310_Dealer_schedule | grep '02:00:00 PM' 0310_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0310_Dealer_schedule | grep '08:00:00 PM' 0310_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0310_Dealer_schedule | grep '11:00:00 PM' 0310_Dealer_schedule | cat >>Dealers_working_during_losses

awk '{print ($1,$2,$5,$6)}' 0312_Dealer_schedule | grep '05:00:00 AM' 0312_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0312_Dealer_schedule | grep '08:00:00 AM' 0312_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0312_Dealer_schedule | grep '02:00:00 PM' 0312_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0312_Dealer_schedule | grep '08:00:00 PM' 0312_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0312_Dealer_schedule | grep '11:00:00 PM' 0312_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0312_Dealer_schedule | grep '05:00:00 AM' 0312_Dealer_schedule | cat >>Dealers_working_during_losses

awk '{print ($1,$2,$5,$6)}' 0315_Dealer_schedule | grep '05:00:00 AM' 0315_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0315_Dealer_schedule | grep '08:00:00 AM' 0315_Dealer_schedule | cat >>Dealers_working_during_losses
awk '{print ($1,$2,$5,$6)}' 0315_Dealer_schedule | grep '02:00:00 PM' 0315_Dealer_schedule | cat >>Dealers_working_during_losses

grep 'Billy Jones' Dealers_working_during_losses | wc -l | cat >>Dealers_working_during_losses

chmod +x Find_Dealer.sh
